declare module 'react-dark-mode-toggle';
